﻿--
-- Database: `test_user`
--
CREATE DATABASE IF NOT EXISTS `test_user` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test_user`;

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `phone` varchar(11) NOT NULL COMMENT '电话号码',
  `password` char(32) NOT NULL COMMENT '密码',
  `salt` char(8) NOT NULL COMMENT 'salt',
  `country_code` varchar(5) NOT NULL DEFAULT '86' COMMENT '国家区号',
  `ip` char(15) NOT NULL COMMENT 'ip',
  `longitude` decimal(13,10) NOT NULL COMMENT '经度',
  `latitude` decimal(13,10) NOT NULL COMMENT '纬度',
  `lastlogintime` int(11) UNSIGNED NOT NULL COMMENT '最后登入时间',
  `device` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '设备类型',
  `region` varchar(10) NOT NULL DEFAULT 'GZ' COMMENT '地区',
  `grade` tinyint(3) UNSIGNED NOT NULL DEFAULT '1' COMMENT '等级',
  `vip` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'vip',
  `status` tinyint(3) UNSIGNED NOT NULL COMMENT '记录状态',
  `addtime` int(11) UNSIGNED NOT NULL COMMENT '添加时间',
  `lastmodify` int(11) UNSIGNED NOT NULL COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_phone` (`phone`),
  KEY `device_INDEX` (`device`),
  KEY `region_index` (`region`),
  KEY `grade_index` (`grade`),
  KEY `country_code` (`country_code`),
  KEY `vip` (`vip`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8;

